#input data
#````````````````````relative abundance based on phylum```````````````````````
library(reshape2)
library(ggplot2)
library(RColorBrewer)
#rock samplings
rock.ph<-read.csv("rock otu_table phylum.csv",header=T)
rock.ph$sum <- rowSums(rock.ph[, 2:6])
#reorder by relative abundance 
rock.ph<-rock.ph[order(rock.ph$sum,decreasing=T),]
sum(rock.ph$sum)-sum(rock.ph$sum[1:10])

rock.re<-rock.ph[c(1:10),]
rock.re<-rock.re[,c(1,8)]
#add one row
rock.re[11,]<-c("Others",7475)
rock.re$sum<-as.numeric(rock.re$sum)
sum(rock.ph$sum)
sum(rock.re$sum)

rock.re1<-melt(rock.re) 
rock.re1$Taxonomy <- factor(rock.re1$Taxonomy, levels =rev(rock.re$Taxonomy))
rer<-ggplot(data=rock.re1,aes(variable,value,fill=Taxonomy))+ 
   geom_bar(stat="identity", position="fill",color="black", width=0.8,size=0.25)+
  theme(axis.title=element_text(size=15,face="plain",color="black"),
        axis.text = element_text(size=12,face="plain",color="black"),
        legend.title=element_text(size=14,face="plain",color="black"),
        legend.position = "right")+labs(x="Rock",y="Relative abundance")+
  scale_fill_manual(values=brewer.pal(11,"Paired")[c(11:1)])+
  theme_classic()
#prop
library("plyr")
prop<-rock.re1[,c(1,3)]
ddply(prop, "Taxonomy", transform,
      percent= value/sum(prop$value)*100)

#soil samplings 
soil.ph<-read.csv("soil otu_table phylum.csv",header=T)
soil.ph$sum <- rowSums(soil.ph[, 2:6])
#
soil.ph<-soil.ph[order(soil.ph$sum,decreasing=T),]
sum(soil.ph$sum)-sum(soil.ph$sum[1:10])

soil.re<-soil.ph[c(1:10),]
soil.re<-soil.re[,c(1,8)]
#
soil.re[11,]<-c("Others",7377)
soil.re$sum<-as.numeric(soil.re$sum)
sum(soil.ph$sum)
sum(soil.re$sum)

soil.re1<-melt(soil.re) 
soil.re1$Taxonomy <- factor(soil.re1$Taxonomy, levels =rev(soil.re$Taxonomy))
ret<-ggplot(data=soil.re1,aes(variable,value,fill=Taxonomy))+ 
  geom_bar(stat="identity", position="fill",color="black", width=0.8,size=0.25)+
  theme(axis.title=element_text(size=15,face="plain",color="black"),
        axis.text = element_text(size=12,face="plain",color="black"),
        legend.title=element_text(size=14,face="plain",color="black"),
        legend.position = "right")+labs(x="Soil",y="Relative abundance")+
  scale_fill_manual(values=brewer.pal(11,"Paired")[c(11:1)])+
  theme_classic()
#
library("plyr")
prop<-soil.re1[,c(1,3)]
ddply(prop, "Taxonomy", transform,
      percent= value/sum(prop$value)*100)


#stalactite samplings
stal.ph<-read.csv("stalactite otu_table phylum.csv",header=T)
stal.ph$sum <- rowSums(stal.ph[, 2:6])
#
stal.ph<-stal.ph[order(stal.ph$sum,decreasing=T),]
sum(stal.ph$sum)-sum(stal.ph$sum[1:10])

stal.re<-stal.ph[c(1:10),]
stal.re<-stal.re[,c(1,8)]
#
stal.re[11,]<-c("Others",7471)
stal.re$sum<-as.numeric(stal.re$sum)
sum(stal.ph$sum)
sum(stal.re$sum)

stal.re1<-melt(stal.re) 
stal.re1$Taxonomy <- factor(stal.re1$Taxonomy, levels =rev(stal.re$Taxonomy))
rez<-ggplot(data=stal.re1,aes(variable,value,fill=Taxonomy))+ 
  geom_bar(stat="identity", position="fill",color="black", width=0.8,size=0.25)+
  theme(axis.title=element_text(size=15,face="plain",color="black"),
        axis.text = element_text(size=12,face="plain",color="black"),
        legend.title=element_text(size=14,face="plain",color="black"),
        legend.position = "right")+labs(x="stalactite",y="Relative abundance")+
  scale_fill_manual(values=brewer.pal(11,"Paired")[c(11:1)])+
  theme_classic()

#
library("plyr")
prop<-stal.re1[,c(1,3)]
ddply(prop, "Taxonomy", transform,
      percent= value/sum(prop$value)*100)

#merge to one plotting
library(easyGgplot2)
#Horizontal A4
pdf("relative abundance stacked bar chart.pdf",width=11.69, height=8.27)
ggplot2.multiplot(rer,ret,rez, cols=3)
dev.off()

rock.re$Taxonomy
soil.re$Taxonomy
stal.re$Taxonomy

#``````````````````````NMDS``````````````
#based on species
#`````````````````````````species```````````````````````
#input data 
#rock samplings
rock.sp<-read.csv("rock otu_table species.csv",header=T)
class(rock)
#soil samplings
soil.sp<-read.csv("soil otu_table species.csv",header=T)
#stalactite samplings
stal.sp<-read.csv("stalactite otu_table species.csv",header=T)
colnames(rock.sp)
species<-merge(rock.sp,soil.sp,all = T,by="Taxonomy")
species<-merge(species,stal.sp,all = T,by="Taxonomy")
row.names(species)<-species$Taxonomy
species<-species[,-c(1,7,13,19)]
colnames(species)
#NA to 0
sum(is.na(species))
species[is.na(species)]<-0
sum(is.na(species))
species<-as.data.frame(t(species))
library(tidyr)
species$gp<-row.names(species)
species<-extract(species, gp, c("site","group"), "(.)(.)",convert=TRUE)

#---------------- Anosim analysis------------------
library(vegan)
library(ggplot2)
library(easyGgplot2)
Anosim.dist<-vegdist(species[,c(1:405)])
Anosim.ano<-anosim(Anosim.dist,species$group,permutations = 999)
Anosim.ano
#rock&soil
rd.dist<-vegdist(subset(species,species$group!="z",select=1:405))
rd.ano<-anosim(rd.dist,subset(species,species$group!="z")$group,permutations = 999)
rd.ano
#ANOSIM statistic R: 0.7 
#Significance: 0.008

#rock&stalatite
rd.dist<-vegdist(subset(species,species$group!="t",select=1:405))
rd.ano<-anosim(rd.dist,subset(species,species$group!="z")$group,permutations = 999)
rd.ano
#ANOSIM statistic R: 0.744 
#Significance: 0.005 

#soil&stalatite
rd.dist<-vegdist(subset(species,species$group!="r",select=1:405))
rd.ano<-anosim(rd.dist,subset(species,species$group!="z")$group,permutations = 999)
rd.ano
#ANOSIM statistic R: 0.788 
#Significance: 0.009 


m<-monoMDS(Anosim.dist)
#View(m)
m#Stress:0.07457321  
plot(m$points)
dat<-as.data.frame(m$points)
dat$group<-species$group

p<-ggplot(dat,aes(MDS1,MDS2,col=group,fill=group,shape=group))
p<-p+geom_point(aes(color = group),size=2)+ 
  scale_shape_manual(values = c(8,4,1))+ 
   stat_ellipse(level = 0.95)+
  theme(axis.title =element_text(size=14),
        axis.text = element_text(size=12),
        legend.title = element_blank())+
  theme_classic()
pdf("NMDS.pdf")
print(p)
dev.off()


#``````````````````Venn diagram``````````````````

#install.packages("VennDiagram")
library(VennDiagram)
library(grDevices)

#rock samplings
rock.venn<-read.table("rock otu_table.txt",sep="\t",row.names =1 ,header=T)
#soil samplings
soil.venn<-read.table("soil otu_table.txt",sep="\t",row.names =1 ,header=T)
#stalactite samplings
stal.venn<-read.table("stalactite otu_table.txt",sep="\t",row.names =1 ,header=T)

Venn.list<-list(rock.venn$Taxonomy,soil.venn$Taxonomy,stal.venn$Taxonomy)
names(Venn.list)<-c("Rock","Soil","stalactite")
venn.diagram<-venn.diagram(Venn.list,alpha=c(0.5),col="white",fill=c("#fbb4ae",
        "#b3cde3", "#ccebc5"),filename =NULL)
pdf("Venn Diagram based on OTU.pdf")
grid.draw(venn.diagram)
dev.off()

#````````````````````LEfse based on genus``````````````````````
#rock samplings
rock4<-read.csv("rock otu_table genus.csv",header=T)

#soil samplings
soil4<-read.csv("soil otu_table genus.csv",header=T)
#stalactite samplings
stal4<-read.csv("stalactite otu_table genus.csv",header=T)
species4<-merge(rock4,soil4,all = T,by="Taxonomy")
species4<-merge(species4,stal4,all = T,by="Taxonomy")
sum(is.na(species4))
colnames(species4)
library(stringr)
write.csv(species4,"lefse0107.csv")
rm(rock4)
rm(soil4)
rm(stal4)
rm(species4)

#````````````````````Function prediction``````````````````````
#rock samplings
rock4<-read.table("rock otu_table.txt",sep="\t",header=T)
#soil samplings
soil4<-read.table("soil otu_table.txt",sep="\t",header=T)
#stalactite samplings
stal4<-read.table("stalactite otu_table.txt",sep="\t",header=T)

species4<-merge(rock4,soil4,all = T,by="Taxonomy")
species4<-merge(species4,stal4,all = T,by="Taxonomy")
species4<-species4[-c(1:68),]
species4<-species4[,-c(2,8,14)]
species4$taxonomy<-species4$Taxonomy
row.names(species4)
species4$Taxonomy<-"OTU_"
species4$id<-row.names(species4)
library(tidyr)
species4<-unite(species4,"OTU ID",Taxonomy,id,remove = FALSE)
species4<-species4[,-c(2,19)]
species4$taxonomy <- gsub('[a-z]__', '', species4$taxonomy)
sum(is.na(species4))
species4[is.na(species4)]<-0
#��otu_table.not_sliva.convert.txt��added at the first row ��# Constructed from biom file��
write.table(species4, 'otu_table.not_sliva.convert.txt', row.names = FALSE, sep = '\t', quote = FALSE)
# uploaded this data to http://huttenhower.sph.harvard.edu/galaxy/ get the results of PICRUSt

#	pathway 1
library(reshape2)
library(ggplot2)
library(RColorBrewer)
library(SuppDists)
library(car)
library(plyr)
library(ggpubr)
pathway1<-read.csv("Pathway1.csv",header = T)
pathway1$Pathway1<-as.factor(pathway1$Pathway1)
colnames(pathway1)
#```````````````````````````````````````````````
library(multcomp)
library(agricolae)
aov <- aov(Cellular.Processes~Pathway1, pathway1)
#LSD
aov.res <- LSD.test(aov, 'Pathway1', p.adj = 'bonferroni')
print(aov.res$groups)
mar<-aov.res$groups
rownamemar<-row.names(mar)
newmar<-data.frame(rownamemar,mar$Cellular.Processes,mar$groups)
sort<-newmar[order(newmar$rownamemar),]
rowname<-row.names(aov.res$means)
mean<-aov.res$means[,1]
sd<-aov.res$means[,2]
marker<-sort$mar.groups
plotdata<-data.frame(rowname,mean,sd,marker)
plotdata

colnames(pathway1)
#```````````````````````````````````````````````
aov <- aov(Environmental.Information.Processing~Pathway1, pathway1)
#LSD
aov.res <- LSD.test(aov, 'Pathway1', p.adj = 'bonferroni')
print(aov.res$groups)
mar<-aov.res$groups
rownamemar<-row.names(mar)
newmar<-data.frame(rownamemar,mar$Environmental.Information.Processing,mar$groups)
sort<-newmar[order(newmar$rownamemar),]
rowname<-row.names(aov.res$means)
mean<-aov.res$means[,1]
sd<-aov.res$means[,2]
marker<-sort$mar.groups
plotdata<-data.frame(rowname,mean,sd,marker)
plotdata


pathway1<-melt(pathway1)
pdf("Pathway10327.pdf")
ggplot(pathway1, aes(x = variable, y = value, fill = Pathway1)) +
  theme_bw() +
  theme(panel.border = element_blank(),panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),axis.line = element_line(colour = "black"))+
    geom_bar(stat = "summary", fun.y = mean, position = position_dodge()) +#position_dodge���ξ���ĵ���
  stat_summary(fun.data = 'mean_sd', geom = "errorbar", colour = "black",
               width = 0.25,position = position_dodge( .9))
 dev.off()


ggplot(pathway1,aes(x=factor(variable),y=value,fill = Pathway1))+
geom_bar(stat="identity",position=position_dodge())+
  coord_flip()+
  theme_bw()+theme(panel.border = element_blank(),panel.grid.major = element_blank(),
                   panel.grid.minor = element_blank(),axis.line = element_line(colour = "black"))+
  theme(axis.text.x=element_text())
dev.off()

pathway1<-read.csv("Pathway1.csv",header = T)
colnames(pathway1)
aov <- aov(Unclassified~Pathway1, pathway1)
#LSD
aov.res <- LSD.test(aov, 'Pathway1', p.adj = 'bonferroni')
print(aov.res$groups)


p6<-ggplot(data=tax4fun_pathway,aes(Pathway2,value,fill=group))+
  geom_bar(stat="identity",position=position_dodge(),width=0.7,size=0.25)+
  coord_flip()+
  theme_bw()+theme(panel.border = element_blank(),panel.grid.major = element_blank(),
                   panel.grid.minor = element_blank(),axis.line = element_line(colour = "black"))+
  theme(axis.text.x=element_text())
pdf("Pathway2.pdf")
print(p6)
dev.off()

#--------------------------heatmap -------------
source("http://bioconductor.org/biocLite.R")
options(BioC_mirror="http://mirrors.ustc.edu.cn/bioc/")
biocLite("ComplexHeatmap")
# installed from GitHub
if(!require(devtools)){install.packages("devtools")}
devtools::install_github("jokergoo/ComplexHeatmap")
library(ComplexHeatmap)
library(circlize)
library(dendextend)
library(stats)
pathway2<-read.csv("Pathway2.csv",header = T)
pathway2 <- aggregate(.~Pathway2,data=pathway2,FUN=mean) 
df<-scale(pathway2[,c(2:42)]) #scale
row.names(df)<-pathway2$Pathway2
row_dend<-hclust(dist(df))  
col_dend<-hclust(dist(t(df))) 
mycol <-rev(brewer.pal(n = 7, name = "RdYlBu"))
pdf("heatmap.pdf",width=11.69, height=8.27)
Heatmap(df, col = mycol,name = "mtcars",rect_gp = gpar(col = "black"),
        column_dend_height = unit(4, "cm"), 
        row_dend_width = unit(4, "cm"),    
        cluster_rows = color_branches(row_dend),
        cluster_columns = color_branches(col_dend)) 
dev.off()





#`````````````````````````network analysis based on genus``````````````````````
#input data 
#rock samplings
rock.ge<-read.csv("rock otu_table genus.csv",header=T,row.names = 1)
rock.ge<-rock.ge[,-6]
rock.ve<-rock.ge
rock.ve$sp<-row.names(rock.ve)
rock.ve$value <- rowMeans(rock.ve[, 1:5])
rock.ve<-rock.ve[,-c(1:5)]
rock.ge<-as.data.frame(t(rock.ge))
rock.ge<-rock.ge[,-468]


#soil samplings
soil.ge<-read.csv("soil otu_table genus.csv",header=T,row.names = 1)
soil.ge<-soil.ge[,-6]
soil.ve<-soil.ge
soil.ve$sp<-row.names(soil.ve)
soil.ve$value <- rowMeans(soil.ve[, 1:5])
soil.ve<-soil.ve[,-c(1:5)]
soil.ge<-as.data.frame(t(soil.ge))
soil.ge<-soil.ge[,-284]


#stalactite samplings
stal.ge<-read.csv("stalactite otu_table genus.csv",header=T,row.names = 1)
stal.ge<-stal.ge[,-6]
stal.ve<-stal.ge
stal.ve$sp<-row.names(stal.ve)
stal.ve$value <- rowMeans(stal.ve[, 1:5])
stal.ve<-stal.ve[,-c(1:5)]
stal.ge<-as.data.frame(t(stal.ge))
stal.ge<-stal.ge[,-467]

library(igraph)
library(psych)
occor <- corr.test(rock.ge,use="pairwise",method="spearman",adjust="fdr",alpha=.05)
occor.r <-occor$r 
occor.p <-occor$p 
occor.r[occor.p>0.01|abs(occor.r)<0.8] = 0 
# igraph objective
igraph.b <-graph_from_adjacency_matrix(occor.r,mode="undirected",weighted=TRUE,diag=FALSE)
# remove isolated nodes
bad.vs<- V(igraph.b)[degree(igraph.b) == 0]
igraph.b<-delete.vertices(igraph.b, bad.vs)
igraph.weight<- E(igraph.b)$weight
E(igraph.b)$weight <- NA
E.color <-igraph.weight
E.color<-ifelse(E.color>0, "grey",ifelse(E.color<0, "red","blue"))
E(igraph.b)$color <-as.character(E.color)
E(igraph.b)$width<- abs(igraph.weight)

#input Phyum
rock.ge<-read.csv("rock otu_table genus.csv",header=T,row.names = 1)
rock.ge$Tax_detail<- gsub('[a-z]__', '', rock.ge$Tax_detail)
library(tidyverse)
rock.ge<-separate(data = rock.ge, col =Tax_detail,
                  into = c("Kingdom","Phylum","Class","Order",
                           "Family","Genus",";"),remove = FALSE)
rock.ge<-rock.ge[,-c(6,7,9:13)]
rock.ge$genus<-row.names(rock.ge)
rock.ge$abundance <- rowMeans(rock.ge[, 1:5])
otu_pro<-rock.ge[,-c(1:5)]
#write.csv(otu_pro,"otu_pro.csv")
otu_pro<-read.csv("otu_pro.csv",header=T,row.names = 1)
# set vertices size
igraph.size<-otu_pro[V(igraph.b)$name,] 
igraph.size1<-log((igraph.size$abundance)*10) 
V(igraph.b)$size <-igraph.size1

# set vertices color
library(RColorBrewer)
igraph.col <-otu_pro[V(igraph.b)$name,]
levels(igraph.col$Phylum)
levels(igraph.col$Phylum)<-brewer.pal(11,"Paired")[c(11:1)]
V(igraph.b)$color<-as.character(igraph.col$Phylum)
E(igraph.b)$width<- abs(igraph.weight)*1
set.seed(12345)
pdf("Co-occurrence network rock.pdf")
plot(igraph.b,main="Co-occurrence network",vertex.frame.color=NA,vertex.label=NA,
     edge.lty=1,edge.curved=TRUE,margin=c(0,0,0,0))
legend(x=1.2,y=1.2, c("Acidobacteria","Actinobacteria", "Bacteroidetes", "Chlorobi",
                      "Chloroflexi","Firmicutes", "Gemmatimonadetes", "Nitrospirae","Others",
                      "Planctomycetes","Proteobacteria"), pch=21,
       pt.bg=brewer.pal(11,"Paired")[c(11:1)], pt.cex=2, cex=.8, bty="n", xpd=TRUE,ncol=1)
dev.off()

# set edge color
edge.start <- ends(igraph.b, es=E(igraph.b), names=F)[,1]
E.color <-V(igraph.b)$color[edge.start]


E(igraph.b)$width<- abs(igraph.weight)*1
set.seed(12345)
pdf("Co-occurrence network rock.pdf")
plot(igraph.b,main="rock Co-occurrence network",vertex.frame.color=NA,
     edge.color=E.color, edge.curved=TRUE,edge.lty=1,
     vertex.label=NA,edge.lty=1,margin=c(0,0,0,0))
legend(x=1.2,y=1.2, c("Acidobacteria","Actinobacteria", "Bacteroidetes", "Chlorobi",
                  "Chloroflexi","Firmicutes", "Gemmatimonadetes", "Nitrospirae","Others",
                  "Planctomycetes","Proteobacteria"), pch=21,
       pt.bg=brewer.pal(11,"Paired")[c(11:1)], pt.cex=2, cex=.8, bty="n", xpd=TRUE,ncol=1)
dev.off()



#````````````````````````soil``````````````
soccor. <- corr.test(soil.ge,use="pairwise",method="spearman",adjust="fdr",alpha=.05)
soccor.r <-soccor.$r 
soccor.p <-soccor.$p
soccor.r[soccor.p>0.01|abs(soccor.r)<0.8] = 0 
igraph.s <-graph_from_adjacency_matrix(soccor.r,mode="undirected",weighted=TRUE,diag=FALSE)
bad.vs<- V(igraph.s)[degree(igraph.s) == 0]
igraph.s<-delete.vertices(igraph.s, bad.vs)

igraph.weight<- E(igraph.s)$weight
E(igraph.s)$weight <- NA
E.color <-igraph.weight
E.color<-ifelse(E.color>0, "grey",ifelse(E.color<0, "red","blue"))
E(igraph.s)$color <-as.character(E.color)

E(igraph.s)$width<- abs(igraph.weight)
soil.ge<-read.csv("soil otu_table genus.csv",header=T,row.names = 1)
soil.ge$Tax_detail<- gsub('[a-z]__', '', soil.ge$Tax_detail)
library(tidyverse)
soil.ge<-separate(data = soil.ge, col =Tax_detail,
                  into = c("Kingdom","Phylum","Class","Order",
                           "Family","Genus",";"),remove = FALSE)
soil.ge<-soil.ge[,-c(6,7,9:13)]
soil.ge$genus<-row.names(soil.ge)
soil.ge$abundance <- rowMeans(soil.ge[, 1:5])
otu_pro<-soil.ge[,-c(1:5)]
write.csv(otu_pro,"soil otu_pro.csv")
otu_pro<-read.csv("soil otu_pro.csv",header=T,row.names = 1)
# set vertices size
igraph.size<-otu_pro[V(igraph.s)$name,] 
igraph.size1<-log((igraph.size$abundance)*10)
V(igraph.s)$size <-igraph.size1

# set vertices color
library(RColorBrewer)
igraph.col <-otu_pro[V(igraph.s)$name,]
levels(igraph.col$Phylum)
levels(igraph.col$Phylum)<-brewer.pal(11,"Paired")[c(11:1)]
V(igraph.s)$color<-as.character(igraph.col$Phylum)
E(igraph.s)$width<- abs(igraph.weight)*1
set.seed(12345)
pdf("Co-occurrence network soil.pdf")
plot(igraph.s,main="Co-occurrence network",vertex.frame.color=NA,vertex.label=NA,
     edge.lty=1,edge.curved=TRUE,margin=c(0,0,0,0))
legend(x=1.2,y=1.2, c("Acidobacteria","Actinobacteria", "Bacteroidetes", "Verrucomicrobia",
                      "Chloroflexi","Firmicutes", "Gemmatimonadetes", "Nitrospirae","Others",
                      "Planctomycetes","Proteobacteria"), pch=21,
       pt.bg=brewer.pal(11,"Paired")[c(11:1)], pt.cex=2, cex=.8, bty="n", xpd=TRUE,ncol=1)
dev.off()


#````````````````````````stalactite``````````````
zoccor<- corr.test(stal.ge,use="pairwise",method="spearman",adjust="fdr",alpha=.05)
zoccor.r <-zoccor$r 
zoccor.p <-zoccor$p 
zoccor.r[zoccor.p>0.01|abs(zoccor.r)<0.8] = 0 
igraph.z <-graph_from_adjacency_matrix(zoccor.r,mode="undirected",weighted=TRUE,diag=FALSE)
bad.vs<- V(igraph.z)[degree(igraph.z) == 0]
igraph.z<-delete.vertices(igraph.z, bad.vs)
igraph.weight<- E(igraph.z)$weight
E(igraph.z)$weight <- NA
E.color <-igraph.weight
E.color<-ifelse(E.color>0, "grey",ifelse(E.color<0, "red","blue"))
E(igraph.z)$color <-as.character(E.color)

E(igraph.z)$width<- abs(igraph.weight)

stal.ge<-read.csv("stalactite otu_table genus.csv",header=T,row.names = 1)
stal.ge$Tax_detail<- gsub('[a-z]__', '', stal.ge$Tax_detail)
library(tidyverse)
stal.ge<-separate(data = stal.ge, col =Tax_detail,
                  into = c("Kingdom","Phylum","Class","Order",
                           "Family","Genus",";"),remove = FALSE)
stal.ge<-stal.ge[,-c(6,7,9:13)]
stal.ge$genus<-row.names(stal.ge)
stal.ge$abundance <- rowMeans(stal.ge[, 1:5])
otu_pro<-stal.ge[,-c(1:5)]
write.csv(otu_pro,"stalactite otu_pro.csv")
otu_pro<-read.csv("stalactite otu_pro.csv",header=T,row.names = 1)

igraph.size<-otu_pro[V(igraph.z)$name,]
igraph.size1<-log((igraph.size$abundance)*10) 
V(igraph.z)$size <-igraph.size1

# set vertices color
library(RColorBrewer)
igraph.col <-otu_pro[V(igraph.z)$name,]
levels(igraph.col$Phylum)
levels(igraph.col$Phylum)<-brewer.pal(11,"Paired")[c(11:1)]

V(igraph.z)$color<-as.character(igraph.col$Phylum)
E(igraph.z)$width<- abs(igraph.weight)*1#�߿���Ϊ5�����ϵ������ֵ��Խ�ִ�����ؾ���ֵԽ��
set.seed(12345)
pdf("Co-occurrence network stalactite.pdf")
plot(igraph.z,main="Co-occurrence network",vertex.frame.color=NA,vertex.label=NA,
     edge.lty=1,edge.curved=TRUE,margin=c(0,0,0,0))
legend(x=1.2,y=1.2, c("Acidobacteria","Actinobacteria", "Bacteroidetes", "Verrucomicrobia",
                      "Chloroflexi","Firmicutes", "Gemmatimonadetes", "Nitrospirae","Others",
                      "Planctomycetes","Proteobacteria"), pch=21,
       pt.bg=brewer.pal(11,"Paired")[c(11:1)], pt.cex=2, cex=.8, bty="n", xpd=TRUE,ncol=1)
dev.off()


#caluculate the parameters of network
occor.r <-occor$r
occor.p <-occor$p
occor.r[occor.p>0.01|abs(occor.r)<0.8] = 0 
igraph.b <-graph_from_adjacency_matrix(occor.r,mode="undirected",weighted=TRUE,diag=FALSE)
bad.vs<- V(igraph.b)[degree(igraph.b) == 0]
igraph.b<-delete.vertices(igraph.b, bad.vs)
igraph.weight<- E(igraph.b)$weight
E(igraph.b)$weight <- NA
E.color.r <-igraph.weight
E.color.r<-ifelse(E.color.r>0, "grey",ifelse(E.color.r<0, "red","blue"))
E(igraph.b)$width<- abs(igraph.weight)
#
soccor.r <-soccor.$r
soccor.p <-soccor.$p
soccor.r[soccor.p>0.01|abs(soccor.r)<0.8] = 0 
igraph.s <-graph_from_adjacency_matrix(soccor.r,mode="undirected",weighted=TRUE,diag=FALSE)
bad.vs<- V(igraph.s)[degree(igraph.s) == 0]
igraph.s<-delete.vertices(igraph.s, bad.vs)
igraph.weight<- E(igraph.s)$weight
E(igraph.s)$weight <- NA
E.color.s <-igraph.weight
E.color.s<-ifelse(E.color.s>0, "grey",ifelse(E.color.s<0, "red","blue"))
E(igraph.s)$width<- abs(igraph.weight)
#
zoccor.r <-zoccor$r 
zoccor.p <-zoccor$p
zoccor.r[zoccor.p>0.01|abs(zoccor.r)<0.8] = 0 
igraph.z <-graph_from_adjacency_matrix(zoccor.r,mode="undirected",weighted=TRUE,diag=FALSE)
bad.vs<- V(igraph.z)[degree(igraph.z) == 0]
igraph.z<-delete.vertices(igraph.z, bad.vs)
igraph.weight<- E(igraph.z)$weight
E(igraph.z)$weight <- NA
E.color.z <-igraph.weight
E.color.z<-ifelse(E.color.z>0, "grey",ifelse(E.color.z<0, "red","blue"))
E(igraph.z)$width<- abs(igraph.weight)

#number of edges
table(unlist(E.color.r))
sum(is.na(E.color.r))
table(unlist(E.color.s))
table(unlist(E.color.z))

#connectance 
edge_density(igraph.b,loops=FALSE)#0.01633107
edge_density(igraph.s,loops=FALSE)#0.04113454
edge_density(igraph.z,loops=FALSE)#0.01387534

#Average degree
mean(igraph::degree(igraph.b))#7.610278
mean(igraph::degree(igraph.s))#10.65385
mean(igraph::degree(igraph.z))#6.243902

#Diameter
diameter(igraph.b, directed = FALSE, unconnected = TRUE, weights = NULL)
#2
diameter(igraph.s, directed = FALSE, unconnected = TRUE, weights = NULL)
#16
diameter(igraph.z, directed = FALSE, unconnected = TRUE, weights = NULL)
#23

#Clustering coefficient
transitivity(igraph.b,type="global")#0.08250707
transitivity(igraph.s,type="global")#0.9737842
transitivity(igraph.z,type="global")#0.736143

#modularity
fc <- cluster_fast_greedy(igraph.b,weights =NULL)
modularity(igraph.b,membership(fc))#0.6596188

fc <- cluster_fast_greedy(igraph.s,weights =NULL)
modularity(igraph.s,membership(fc))#0.711642

fc <- cluster_fast_greedy(igraph.z,weights =NULL)
modularity(igraph.z,membership(fc))#0.8688213

#Average path length
average.path.length(igraph.b)#1.983669
average.path.length(igraph.s)#3.657267
average.path.length(igraph.z)#7.835545

#count up the node degrees
#ROCK
library(statnet)
net<-network(get.adjacency(igraph.b,sparse=FALSE))
net %v% 'vertex.names'
detach("package:igraph")
degree(net, gmode = "graph")
rkey<-as.data.frame(net %v% 'vertex.names')
rkey$count<-degree(net, gmode = "graph")
round(betweenness(net,gmode="graph"),2)

colnames(rkey)<-c("group","count")
write.csv(rkey,"rkey.csv")

library(igraph)
#SOIL
net1<-network(get.adjacency(igraph.s,sparse=FALSE))
net1 %v% 'vertex.names'
detach("package:igraph")
degree(net1, gmode = "graph")
skey<-as.data.frame(net1 %v% 'vertex.names')
skey$count<-degree(net1, gmode = "graph")
colnames(skey)<-c("group","count")
write.csv(skey,"skey.csv")

#STALACTITE
library(igraph)
net3<-network(get.adjacency(igraph.z,sparse=FALSE))
net3 %v% 'vertex.names'
detach("package:igraph")
degree(net3, gmode = "graph")
zkey<-as.data.frame(net3 %v% 'vertex.names')
zkey$count<-degree(net3, gmode = "graph")
colnames(zkey)<-c("group","count")
write.csv(zkey,"zkey.csv")

#random network
#input data 
#rock samplings
rock.ge<-read.csv("rock otu_table genus.csv",header=T,row.names = 1)
rock.ge<-rock.ge[,-6]
rock.ve<-rock.ge
rock.ve$sp<-row.names(rock.ve)
rock.ve$value <- rowMeans(rock.ve[, 1:5])
rock.ve<-rock.ve[,-c(1:5)]
rock.ge<-as.data.frame(t(rock.ge))
rock.ge<-rock.ge[,-468]

#soil samplings
soil.ge<-read.csv("soil otu_table genus.csv",header=T,row.names = 1)
soil.ge<-soil.ge[,-6]
soil.ve<-soil.ge
soil.ve$sp<-row.names(soil.ve)
soil.ve$value <- rowMeans(soil.ve[, 1:5])
soil.ve<-soil.ve[,-c(1:5)]
soil.ge<-as.data.frame(t(soil.ge))
soil.ge<-soil.ge[,-284]

#stalactite samplings
stal.ge<-read.csv("stalactite otu_table genus.csv",header=T,row.names = 1)
stal.ge<-stal.ge[,-6]
stal.ve<-stal.ge
stal.ve$sp<-row.names(stal.ve)
stal.ve$value <- rowMeans(stal.ve[, 1:5])
stal.ve<-stal.ve[,-c(1:5)]
stal.ge<-as.data.frame(t(stal.ge))
stal.ge<-stal.ge[,-467]

webs<-list(rock.ge,soil.ge,stal.ge)
webs.names<-c("rock","soil","stalactite")
names(webs)<-webs.names
library(bipartite)
# Make null models for all sites using the r2dtable null
net.nulls.r2d <- lapply(webs, nullmodel, method = "r2dtable", N = 500) 
# Calculate network metric links per species for all plant-pollinator sites
net.metrics.links <- lapply(webs, networklevel, index = 'links per species') 
# Null distribution function for links per species - calculates the network links per species metric for each null (using a particular null method) for each site 
net.null.links<-function(nulls){
  net.null.metric <- list()
  for (i in 1:length(nulls)) {
    net.null.metric[[i]] = do.call('rbind', 
                                   lapply(nulls[[i]], networklevel, index = 'links per species'))
  }
  names(net.null.metric) <- webs.names
  return(net.null.metric)
}
r2d.links <- net.null.links(net.nulls.r2d)

# Z-score function for comparing different networks
net.zscore <- function(obsval, nullval) {
  (obsval - mean(nullval))/sd(nullval)  
} 

# Function that perform z-score calculation of links per species using the observed and null networks
links.zscore<- function(nulltype){
  net.links.zscore <- list() 
  for(i in 1:length(net.metrics.links)){
    net.links.zscore[[i]] = net.zscore(net.metrics.links[[i]]['links per species'], 
                                       nulltype[[i]][ ,'links per species'])
  }
  names(net.links.zscore) <- webs.names
  return(net.links.zscore)
}
r2d.links.zscore <- links.zscore(r2d.links)

# Function that adds p-values according to the obtained z-scores
add.pvalues<- function(net.metric.zscore){
  # Change the output class from list of a list into a matrix
  net.metric.zscore <- do.call('rbind', net.metric.zscore) 
  
  # Convert z-scores to p-values (two-sided)
  net.metric.pvalue <- 2*pnorm(-abs(net.metric.zscore))
  
  # Change matrix into a dataframe
  net.metric.pvalue <- as.data.frame(as.table(net.metric.pvalue))
  colnames(net.metric.pvalue) <- c('site', 'metric', 'pvalue')
  
  net.metric.pvalue <- within(net.metric.pvalue, {
    significance <- ifelse(pvalue <= 0.001, "***", 
                           ifelse(pvalue <= 0.01, "**",
                                  ifelse(pvalue <= 0.05, "*", "not significant")))
  })
  return(net.metric.pvalue)
} 
# Add the p-values to our links per species results
r2d.test.links <- add.pvalues(r2d.links.zscore)
# Print the links per species results
print(r2d.test.links)

#
#rock samplings
rock.ge<-read.csv("rock otu_table genus.csv",header=T,row.names = 1)
rock.ge<-rock.ge[,-6]
rock.ge<-as.data.frame(t(rock.ge))
#soil samplings
soil.ge<-read.csv("soil otu_table genus.csv",header=T,row.names = 1)
soil.ge<-soil.ge[,-6]
soil.ge<-as.data.frame(t(soil.ge))
#stalactite samplings
stal.ge<-read.csv("stalactite otu_table genus.csv",header=T,row.names = 1)
stal.ge<-stal.ge[,-6]
stal.ge<-as.data.frame(t(stal.ge))
library(bipartite)
net.rock<-networklevel(rock.ge)
net.soil<-networklevel(soil.ge)
net.stal<-networklevel(stal.ge)

clp <- cluster_label_prop(igraph.b)
plot(clp, igraph.b,vertex.frame.color=NA,vertex.label=NA)



#```````````````````` �� diversity index````````````````````````
#rock samplings
rock0<-read.table("rock otu.txt",sep="\t",row.names =1 ,header=T)

#soil samplings
soil0<-read.table("soil otu.txt",sep="\t",row.names =1 ,header=T)


#stalactite samplings
stal0<-read.table("stalactite otu.txt",sep="\t",row.names =1 ,header=T)
colnames(stal0)

library(vegan)
library(ggplot2)
# Calculate sample �� diversity
H1 <- data.frame(diversity(rock0))
simpson1 <- data.frame(diversity(rock0, "simpson"))
shannon1<-data.frame(diversity(rock0, "shannon"))
invsimp1 <- data.frame(diversity(rock0, "inv"))
alpha1 <- data.frame(fisher.alpha(rock0))

# Species richness (S) and Pielou's evenness (J):
S1 <- data.frame(specnumber(rock0))
J1 <- data.frame(H1/log(S1))
diversity.a1<-cbind(simpson1, shannon1, invsimp1, alpha1, S1, J1)
diversity.a1$Sample<-row.names(diversity.a1)
names(diversity.a1)<-c("Simpson", "Shannon", "InvSimpson", "Alpha", "SpeciesNo",
                       "Evenness", "Sample")
diversity.a1<-diversity.a1[,c(7,1,2,3,4,5,6)]

H1 <- data.frame(diversity(soil0))
simpson1 <- data.frame(diversity(soil0, "simpson"))
shannon1<-data.frame(diversity(soil0, "shannon"))
invsimp1 <- data.frame(diversity(soil0, "inv"))
alpha1 <- data.frame(fisher.alpha(soil0))

# Species richness (S) and Pielou's evenness (J):
S1 <- data.frame(specnumber(soil0))
J1 <- data.frame(H1/log(S1))
diversity.a2<-cbind(simpson1, shannon1, invsimp1, alpha1, S1, J1)
diversity.a2$Sample<-row.names(diversity.a2)
names(diversity.a2)<-c("Simpson", "Shannon", "InvSimpson", "Alpha", "SpeciesNo",
                       "Evenness", "Sample")
diversity.a3<-diversity.a2[,c(7,1,2,3,4,5,6)]


H1 <- data.frame(diversity(stal0))
simpson1 <- data.frame(diversity(stal0, "simpson"))
shannon1<-data.frame(diversity(stal0, "shannon"))
invsimp1 <- data.frame(diversity(stal0, "inv"))
alpha1 <- data.frame(fisher.alpha(stal0))

# Species richness (S) and Pielou's evenness (J):
S1 <- data.frame(specnumber(stal0))
J1 <- data.frame(H1/log(S1))
diversity.a3<-cbind(simpson1, shannon1, invsimp1, alpha1, S1, J1)
diversity.a3$Sample<-row.names(diversity.a3)
names(diversity.a3)<-c("Simpson", "Shannon", "InvSimpson", "Alpha", "SpeciesNo",
                       "Evenness", "Sample")
diversity.a3<-diversity.a3[,c(7,1,2,3,4,5,6)]

diversity.a1<-rbind(diversity.a1,diversity.a2,diversity.a3)
write.csv(diversity.a1,"diversity.a1.csv")
